/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/


/**
 * Define Global Variables
*/

const sections = document.querySelectorAll('section');
const navbar = document.getElementById('navbar__list');



//Navbar function
function createListItem(){
    for (section of sections){
        sectionName=section.getAttribute('data-nav')
        sectionid=section.getAttribute('id');
        listItem=document.createElement('li');
        listItem.innerHTML=`<a class = 'menu__link' href='#${sectionid}'>${sectionName}</a>`;
        navbar.appendChild(listItem)
    }
}
createListItem();

//deactivat and activat the sections
window.addEventListener('scroll',()=>{
    const activeSection = document.getElementsByClassName('your-active-class')[0];
        if(activeSection !== undefined){
            activeSection.classList.remove('your-active-class')
        };
 sections.forEach(section => {
     const react = section.getBoundingClientRect();
     if(react.top >=-50 && react.top<350){
         section.classList.add('your-active-class');
        };
    });
});
    
//To Top Button  
var scrollButton = document.getElementById("scrollTop");
document.onscroll = function () {
    if (scrollY > 600) {
        scrollButton.style.opacity = '0.8';
    } else {
        scrollButton.style.opacity = '0';
    }
}
scrollButton.onclick = function () {
    window.scrollTo(0, 0)
}